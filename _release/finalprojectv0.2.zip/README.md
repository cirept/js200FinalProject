finalproject

Eric Tanaka
Jun Kim

# how to run game

1.  install node.js

2.  install all dependencies

3.  make 'authorization_code' your base folder

    type this in your node console.


    cd /d INSERT_FULL_PATH_HERE_TO_PROJECT_FOLDER

4.  type


    node app.js

5.  open Chrome browser and navigate to


    localhost:8888
